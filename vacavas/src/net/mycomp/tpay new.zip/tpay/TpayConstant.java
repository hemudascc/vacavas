package net.mycomp.tpay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface TpayConstant {
	
	String PIN_SEND_TOKEN_MSISDN_CACHE_PREFIX="PIN_SEND_TOKEN_MSISDN_CACHE_PREFIX";
	String PIN_VERIFY_TOKEN_MSISDN_CACHE_PREFIX="PIN_VERIFY_TOKEN_MSISDN_CACHE_PREFIX";
	String PIN_SUBSCRIPTIONCONTRACTID_MSISDN_CACHE_PREFIX="PIN_SUBSCRIPTIONCONTRACTID_MSISDN_CACHE_PREFIX";
	List<TpayServiceConfig> tpayServiceConfigration = new ArrayList<>();
	Map<Integer, TpayServiceConfig> mapServiceIdToTpayServiceConfig = new HashMap<>();
	Map<String,String> HEADER_MAP=new HashMap<>();
	
	
	//These are common API parameters
	String CUSTOMER_ACCOUNT_NUMBER="tpayvaca";
	String EXECUTE_INITIAL_PAYMENT_NOW="false";
	String EXECUTE_RECURRING_PAYMENT_NOW="false";
	String AUTO_RENEW_CONTRACT="true";
	String SEND_VERIFICATION_SMS="true";
}
