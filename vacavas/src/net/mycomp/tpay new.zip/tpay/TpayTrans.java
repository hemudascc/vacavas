package net.mycomp.tpay;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tb_tpay_trans")
public class TpayTrans {
	
	@Id
	@GeneratedValue
	private Integer id;
	@Column(name="request_type")
	private String requestType;
	@Column(name="msisdn")
	private String msisdn;
	@Column(name="service_id")
	private String serviceId;
	@Column(name="token")
	private String token;
	@Column(name="token_id")
	private Integer tokenId;
	@Column(name="request")
	private String request;
	@Column(name="response")
	private String response;
	@Column(name="response_code")
	private Integer responseCode;
	@Column(name="create_time")
	private Timestamp createTime;
	@Column(name="status")
	private Boolean status;
	
	public TpayTrans() {}
	public TpayTrans(Boolean status) {
		this.createTime = new Timestamp(System.currentTimeMillis());
		this.status=status;
	}
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public Integer getTokenId() {
		return tokenId;
	}
	public void setTokenId(Integer tokenId) {
		this.tokenId = tokenId;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public Integer getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "TpayTrans [id=" + id + ", requestType=" + requestType + ", msisdn=" + msisdn + ", serviceId="
				+ serviceId + ", token=" + token + ", tokenId=" + tokenId + ", request=" + request + ", response="
				+ response + ", responseCode=" + responseCode + ", createTime=" + createTime + ", status=" + status
				+ "]";
	}
}
