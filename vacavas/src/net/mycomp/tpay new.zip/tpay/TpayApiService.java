package net.mycomp.tpay;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.common.service.IDaoService;
import net.common.service.RedisCacheService;
import net.persist.bean.VWServiceCampaignDetail;
import net.process.bean.CGToken;
import net.util.HttpURLConnectionUtil;
import net.util.JsonMapper;
import net.util.MData;

@Service
public class TpayApiService {
	private static final Logger logger = Logger.getLogger(TpayApiService.class);
	
	private HttpURLConnectionUtil httpURLConnectionUtil;
	
	@Autowired
	private IDaoService daoService;
	
	@Autowired
	private RedisCacheService redisCacheService;
	
	private String pinSendURL;
	
	  public boolean sendPin(TpayRequest tpayRequest) {
		  TpayTrans tpayTrans = new TpayTrans(true);
		  Map<String, String> requestMap = new HashMap<>();
		  CGToken cgToken = new CGToken(tpayRequest.getToken());
		  
		try {
			VWServiceCampaignDetail vwServiceCampaignDetail = MData.mapCamapignIdToVWServiceCampaignDetail.get(cgToken.getCampaignId());
			TpayServiceConfig tpayServiceConfig = TpayConstant.mapServiceIdToTpayServiceConfig.get(vwServiceCampaignDetail.getServiceId());
			
			tpayTrans.setRequestType(TpayRequestType.SEND_OTP.action);
			tpayTrans.setToken(cgToken.getCGToken());
			tpayTrans.setTokenId(cgToken.getTokenId());
			tpayTrans.setMsisdn(tpayRequest.getMsisdn());
			TpayApiRequest tpayApiRequest = TpayApiRequest.getSendPinRequest().setMsisdn(tpayRequest.getMsisdn())
					.setOperatorCode(tpayServiceConfig.getOperatorCode()).setSubscriptionPlanId(tpayServiceConfig.getSubscriptionPlanId())
					.setInitialPaymentproductId(tpayServiceConfig.getPaymentProductId()).setRecurringPaymentproductId(tpayServiceConfig.getPaymentProductId())
					.setProductCatalogName(tpayServiceConfig.getCatalogName()).setLanguage(tpayRequest.getLang())
					.setHeaderEnrichmentReferenceCode(tpayRequest.getHeRefCode()).setSessionToken(tpayRequest.getSessionToken()==null?"":tpayRequest.getSessionToken());
			
			
			
		} catch (Exception e) {
			logger.error("error while sending pin request:"+tpayRequest, e);
			return false;
		}finally {
			daoService.saveObject(tpayTrans);
		}  
		  return false;
	  }
	  
	  public boolean verifyPin(TpayRequest tpayRequest) {
		  
		  TpayTrans tpayTrans = new TpayTrans(true);
			try {
				// TODO
			} catch (Exception e) {
				logger.error("error while verifying pin request:"+tpayRequest, e);
			}finally {
				daoService.saveObject(tpayTrans);
			}  
		  
		  return false;
	  }
	  
	  public boolean resendPin(TpayRequest tpayRequest) {
		  TpayTrans tpayTrans = new TpayTrans(true);
			try {
				// TODO
			} catch (Exception e) {
				logger.error("error while re sending pin request:"+tpayRequest, e);
			}finally {
				daoService.saveObject(tpayTrans);
			}  
		  return false;
	  }
	  
	  public boolean unsubscribe(TpayRequest tpayRequest) {
		  TpayTrans tpayTrans = new TpayTrans(true);
			try {
				// TODO
			} catch (Exception e) {
				logger.error("error while unsubscribing request:"+tpayRequest, e);
			}finally {
				daoService.saveObject(tpayTrans);
			}  
		  return false;
	  }
	  
	  public boolean sendWelocmeMT(TpayRequest tpayRequest) {
		  TpayTrans tpayTrans = new TpayTrans(true);
			try {
				// TODO
			} catch (Exception e) {
				logger.error("error while sendig welcome mt request:"+tpayRequest, e);
			}finally {
				daoService.saveObject(tpayTrans);
			}  
		  return false;
	  }
	  
	  public boolean sendContentMT(TpayRequest tpayRequest) {
		  TpayTrans tpayTrans = new TpayTrans(true);
			try {
				// TODO
			} catch (Exception e) {
				logger.error("error while sending content mt request:"+tpayRequest, e);
			}finally {
				daoService.saveObject(tpayTrans);
			}  
		  return false;
	  }
	public static void main(String [] args) {
		
	}
}
