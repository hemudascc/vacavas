package net.mycomp.tpay;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class TpayUtill {
	
	
	public static String hmacSHA256(String message, byte[] key) {
		MessageDigest sha256 = null;
		try {
			sha256 = MessageDigest.getInstance("SHA-256");
		} catch (Exception e) {
		}
		if (key.length > 64) {
			sha256.update(key);
			key = sha256.digest();
			sha256.reset();
		}
		byte block[] = new byte[64];
		for (int i = 0; i < key.length; ++i)
			block[i] = key[i];
		for (int i = key.length; i < block.length; ++i)
			block[i] = 0;
		for (int i = 0; i < 64; ++i)
			block[i] ^= 0x36;
		sha256.update(block);
		try {
			sha256.update(message.getBytes("UTF-8"));
		} catch (Exception e) {
		}
		byte[] hash = sha256.digest();
		sha256.reset();
		for (int i = 0; i < 64; ++i)
			block[i] ^= (0x36 ^ 0x5c);
		sha256.update(block);
		sha256.update(hash);
		hash = sha256.digest();
		char[] hexadecimals = new char[hash.length * 2];
		for (int i = 0; i < hash.length; ++i) {
			for (int j = 0; j < 2; ++j) {
				int value = (hash[i] >> (4 - 4 * j)) & 0xf;
				char base = (value < 10) ? ('0') : ('a' - 10);
				hexadecimals[i * 2 + j] = (char) (base + value);
			}
		}
		return new String(hexadecimals);
	}
	
	public static String getCurrentTimeStamp() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		return sdf.format(date);
	}
	
	public static String getNextWeekTimeStamp() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		return sdf.format(addDays(date, 5*365));
	}
	
	private static Date addDays(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		return cal.getTime();
	}
}
