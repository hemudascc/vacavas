package net.mycomp.tpay;

import javax.persistence.Column;
import javax.persistence.Id;

public class TpayServiceConfig {
	
	@Id
	@Column(name="id")
	private Integer id;
	@Column(name="service_id")
	private Integer serviceId;
	@Column(name="subscription_plan_id")
	private String subscriptionPlanId;
	@Column(name="catalog_name")
	private String catalogName;
	@Column(name="payment_product_id")
	private String paymentProductId;
	@Column(name="operator_code")
	private String operatorCode;
	@Column(name="country")
	private String country;
	@Column(name="portal_url")
	private String portalURL;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getServiceId() {
		return serviceId;
	}
	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}
	public String getSubscriptionPlanId() {
		return subscriptionPlanId;
	}
	public void setSubscriptionPlanId(String subscriptionPlanId) {
		this.subscriptionPlanId = subscriptionPlanId;
	}
	public String getCatalogName() {
		return catalogName;
	}
	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}
	public String getPaymentProductId() {
		return paymentProductId;
	}
	public void setPaymentProductId(String paymentProductId) {
		this.paymentProductId = paymentProductId;
	}
	public String getOperatorCode() {
		return operatorCode;
	}
	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPortalURL() {
		return portalURL;
	}
	public void setPortalURL(String portalURL) {
		this.portalURL = portalURL;
	}
	
	

}
