package net.mycomp.tpay;

public class TpayRequest {
	
	private String token;
	private String msisdn;
	private String lang;
	private String sessionToken;
	private String heRefCode;
	private String pin;
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getSessionToken() {
		return sessionToken;
	}
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}
	public String getHeRefCode() {
		return heRefCode;
	}
	public void setHeRefCode(String heRefCode) {
		this.heRefCode = heRefCode;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	@Override
	public String toString() {
		return "TpayRequest [token=" + token + ", msisdn=" + msisdn + ", lang=" + lang + ", sessionToken="
				+ sessionToken + ", heRefCode=" + heRefCode + ", pin=" + pin + "]";
	}
}
