package net.mycomp.tpay;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TpayApiRequest {
	
	private String customerAccountNumber;
	private String msisdn;
	private String operatorCode;
	private String subscriptionPlanId;
	private String initialPaymentproductId;
	private String initialPaymentDate;
	private String executeInitialPaymentNow;
	private String executeRecurringPaymentNow;
	private String recurringPaymentproductId;
	private String productCatalogName;
	private String autoRenewContract;
	private String sendVerificationSMS;
	private String allowMultipleFreeStartPeriods;
	private String contractStartDate;
	private String contractEndDate;
	private String language;
	private String headerEnrichmentReferenceCode;
	private String smsId;
	private String signature;
	private String sessionToken;
	private String pinCode;
	private String charge;
	private String transactionId;
	
	public static TpayApiRequest getSendPinRequest(){
		TpayApiRequest tpayApiRequest = new TpayApiRequest();
		tpayApiRequest = tpayApiRequest.setCustomerAccountNumber(TpayConstant.CUSTOMER_ACCOUNT_NUMBER)
					  .setInitialPaymentDate(TpayUtill.getCurrentTimeStamp()+"Z")
					  .setExecuteInitialPaymentNow("false")
					  .setExecuteRecurringPaymentNow("false")
					  .setAutoRenewContract("true")
					  .setSendVerificationSMS("true")
					  .setAllowMultipleFreeStartPeriods("false")
					  .setContractStartDate(TpayUtill.getCurrentTimeStamp()+"Z")
					  .setContractEndDate(TpayUtill.getNextWeekTimeStamp()+"Z");
		return tpayApiRequest;
	}
	
	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}
	public TpayApiRequest setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
		return this;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public TpayApiRequest setMsisdn(String msisdn) {
		this.msisdn = msisdn;
		return this;
	}
	public String getOperatorCode() {
		return operatorCode;
	}
	public TpayApiRequest setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
		return this;
	}
	public String getSubscriptionPlanId() {
		return subscriptionPlanId;
	}
	public TpayApiRequest setSubscriptionPlanId(String subscriptionPlanId) {
		this.subscriptionPlanId = subscriptionPlanId;
		return this;
	}
	public String getInitialPaymentproductId() {
		return initialPaymentproductId;
	}
	public TpayApiRequest setInitialPaymentproductId(String initialPaymentproductId) {
		this.initialPaymentproductId = initialPaymentproductId;
		return this;
	}
	public String getInitialPaymentDate() {
		return initialPaymentDate;
	}
	public TpayApiRequest setInitialPaymentDate(String initialPaymentDate) {
		this.initialPaymentDate = initialPaymentDate;
		return this;
	}
	public String getExecuteInitialPaymentNow() {
		return executeInitialPaymentNow;
	}
	public TpayApiRequest setExecuteInitialPaymentNow(String executeInitialPaymentNow) {
		this.executeInitialPaymentNow = executeInitialPaymentNow;
		return this;
	}
	public String getExecuteRecurringPaymentNow() {
		return executeRecurringPaymentNow;
	}
	public TpayApiRequest setExecuteRecurringPaymentNow(String executeRecurringPaymentNow) {
		this.executeRecurringPaymentNow = executeRecurringPaymentNow;
		return this;
	}
	public String getRecurringPaymentproductId() {
		return recurringPaymentproductId;
	}
	public TpayApiRequest setRecurringPaymentproductId(String recurringPaymentproductId) {
		this.recurringPaymentproductId = recurringPaymentproductId;
		return this;
	}
	public String getProductCatalogName() {
		return productCatalogName;
	}
	public TpayApiRequest setProductCatalogName(String productCatalogName) {
		this.productCatalogName = productCatalogName;
		return this;
	}
	public String getAutoRenewContract() {
		return autoRenewContract;
	}
	public TpayApiRequest setAutoRenewContract(String autoRenewContract) {
		this.autoRenewContract = autoRenewContract;
		return this;
	}
	public String getSendVerificationSMS() {
		return sendVerificationSMS;
	}
	public TpayApiRequest setSendVerificationSMS(String sendVerificationSMS) {
		this.sendVerificationSMS = sendVerificationSMS;
		return this;
	}
	public String getAllowMultipleFreeStartPeriods() {
		return allowMultipleFreeStartPeriods;
	}
	public TpayApiRequest setAllowMultipleFreeStartPeriods(String allowMultipleFreeStartPeriods) {
		this.allowMultipleFreeStartPeriods = allowMultipleFreeStartPeriods;
		return this;
	}
	public String getContractStartDate() {
		return contractStartDate;
	}
	public TpayApiRequest setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
		return this;
	}
	public String getContractEndDate() {
		return contractEndDate;
	}
	public TpayApiRequest setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
		return this;
	}
	public String getLanguage() {
		return language;
	}
	public TpayApiRequest setLanguage(String language) {
		this.language = language;
		return this;
	}
	public String getHeaderEnrichmentReferenceCode() {
		return headerEnrichmentReferenceCode;
	}
	public TpayApiRequest setHeaderEnrichmentReferenceCode(String headerEnrichmentReferenceCode) {
		this.headerEnrichmentReferenceCode = headerEnrichmentReferenceCode;
		return this;
	}
	public String getSmsId() {
		return smsId;
	}
	public TpayApiRequest setSmsId(String smsId) {
		this.smsId = smsId;
		return this;
	}
	public String getSignature() {
		return signature;
	}
	public TpayApiRequest setSignature(String signature) {
		this.signature = signature;
		return this;
	}
	public String getSessionToken() {
		return sessionToken;
	}
	public TpayApiRequest setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
		return this;
	}
	public String getPinCode() {
		return pinCode;
	}
	public TpayApiRequest setPinCode(String pinCode) {
		this.pinCode = pinCode;
		return this;
	}
	public String getCharge() {
		return charge;
	}
	public TpayApiRequest setCharge(String charge) {
		this.charge = charge;
		return this;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public TpayApiRequest setTransactionId(String transactionId) {
		this.transactionId = transactionId;
		return this;
	}
	
	
}
