package net.mycomp.tpay;

public enum TpayRequestType {
	
	SEND_OTP("SEND_OTP"),
	VERIFY_OTP("VERIFY_OTP"),
	RESEND_OTP("RESEND_OTP"),
	UNSUBSCRIBE("UNSUBSCRIBE");
	public String action;
	private TpayRequestType(String sendOtp) {
		this.action=sendOtp;
	}		
}
