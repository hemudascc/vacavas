package net.mycomp.tpay;

import org.springframework.stereotype.Service;

@Service
public class TpayService {
	
	
	
}
